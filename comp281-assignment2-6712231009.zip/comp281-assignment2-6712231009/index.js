import * as THREE from 'three';
import { CSS2DRenderer, CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { GUI } from 'three/addons/libs/lil-gui.module.min.js';
import Stats from 'three/addons/libs/stats.module.js';
import { M3D, createLabel2D, FPS } from './utils-module.js';

document.addEventListener("DOMContentLoaded", main);

function main() {
	document.body.appendChild(M3D.renderer.domElement);
	document.body.appendChild(M3D.cssRenderer.domElement);

	M3D.renderer.setClearColor(0x87ceeb); // สีท้องฟ้า
	M3D.renderer.setPixelRatio(window.devicePixelRatio);
	M3D.renderer.shadowMap.enabled = true;
	M3D.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
	M3D.renderer.physicallyCorrectLights = true;
	M3D.renderer.outputEncoding = THREE.sRGBEncoding;
	M3D.renderer.setAnimationLoop(animate);

	// ===== แสง =====
	const ambient = new THREE.AmbientLight(0xffffff, 0.5);
	const sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
	sunLight.position.set(100, 200, 100);
	sunLight.castShadow = true;
	M3D.scene.add(ambient, sunLight);

	// ===== พื้นดิน (ท้องนา) =====
	const groundGeo = new THREE.PlaneGeometry(1000, 1000);
	const groundMat = new THREE.MeshLambertMaterial({ color: 0x55aa55 });
	const ground = new THREE.Mesh(groundGeo, groundMat);
	ground.rotation.x = -Math.PI / 2;
	ground.receiveShadow = true;
	M3D.scene.add(ground);

	// ===== ภูเขา =====
	const mountainGeo = new THREE.ConeGeometry(120, 300, 32);
	const mountainMat = new THREE.MeshStandardMaterial({ color: 0x888877 });

	// ภูเขาลูกที่ 1
	const mountain1 = new THREE.Mesh(mountainGeo, mountainMat);
	mountain1.position.set(-250, 150, -200);
	mountain1.castShadow = true;

	// ภูเขาลูกที่ 2
	const mountain2 = mountain1.clone();
	mountain2.position.set(-100, 200, -350);
	mountain2.scale.set(1.5, 1.5, 1.5);
	mountain2.castShadow = true;

	// ภูเขาลูกที่ 3 
	const mountain3 = mountain1.clone();
	mountain3.position.set(100, 180, -250);
	mountain3.scale.set(1.2, 1.2, 1.2);
	mountain3.castShadow = true;

	M3D.scene.add(mountain1, mountain2, mountain3);


	// ===== พระอาทิตย์ =====
	const sunGeo = new THREE.SphereGeometry(50, 32, 32);
	const sunMat = new THREE.MeshBasicMaterial({ color: 0xffdd33, emissive: 0xffdd33 });
	const sun = new THREE.Mesh(sunGeo, sunMat);
	sun.position.set(300, 400, -500);
	M3D.scene.add(sun);

	// ===== แม่น้ำ =====
	const riverGeo = new THREE.PlaneGeometry(1000, 100);
	const riverMat = new THREE.MeshPhongMaterial({ color: 0x3388ff, transparent: true, opacity: 0.8 });
	const river = new THREE.Mesh(riverGeo, riverMat);
	river.rotation.x = -Math.PI / 2;
	river.position.set(0, 0.1, 250);
	river.receiveShadow = true;
	M3D.scene.add(river);

	// ===== ต้นไม้  =====
	const treeGroup = new THREE.Group();
	for (let i = 0; i < 30; i++) {
		const trunk = new THREE.Mesh(
			new THREE.CylinderGeometry(2, 2, 20),
			new THREE.MeshStandardMaterial({ color: 0x8b4513 })
		);
		const leaves = new THREE.Mesh(
			new THREE.ConeGeometry(10, 20, 8),
			new THREE.MeshStandardMaterial({ color: 0x228b22 })
		);
		leaves.position.y = 15;
		const tree = new THREE.Group();
		tree.add(trunk, leaves);
		tree.position.set(Math.random() * 400 - 180, 7, Math.random() * 400 - 200);
		treeGroup.add(tree);
	}
	M3D.scene.add(treeGroup);

	// ===== บ้าน/กระท่อม =====
	const house = new THREE.Group();
	const wall = new THREE.Mesh(
		new THREE.BoxGeometry(40, 30, 40),
		new THREE.MeshStandardMaterial({ color: 0x8b4513 })
	);
	wall.position.y = 15;

	const roof = new THREE.Mesh(
		new THREE.ConeGeometry(30, 20, 4),
		new THREE.MeshStandardMaterial({ color: 0x87CEEB })
	);
	roof.position.y = 40;
	roof.rotation.y = Math.PI / 4;

	house.add(wall, roof);
	house.position.set(150, 0, 50);
	M3D.scene.add(house);

	// ===== สร้างก้อนเมฆ =====
	const cloudGeo = new THREE.SphereGeometry(15, 16, 16);
	const cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff });

	// ===== กล้อง =====
	M3D.camera.position.set(200, 200, 300);
	M3D.controls.target.set(0, 50, 0);
	M3D.controls.update();

	// ===== Stats & GUI =====
	const stats = new Stats();
	document.body.appendChild(stats.dom);
	const gui = new GUI();

	// GUI สามารถปรับแสงหรือสีพื้นหลังได้
	const lightFolder = gui.addFolder("Sun Light");
	lightFolder.add(sunLight.position, "x", -500, 500);
	lightFolder.add(sunLight.position, "y", 0, 500);
	lightFolder.add(sunLight.position, "z", -500, 500);

	function animate() {
		M3D.controls.update();
		stats.update();
		FPS.update();

		// อัปเดตพระอาทิตย์หมุน
		sun.rotation.y += 0.001;

		M3D.renderer.render(M3D.scene, M3D.camera);
		M3D.cssRenderer.render(M3D.scene, M3D.camera);
	}
}
